export const environment = {
  production: true,
  API_KEY: 'api_key=c4f351490cb39722773a30b3347f2e0d',
  JSONSERVER:'http://localhost:3000' 
};
