export interface Preferences {
    language: string;
    genre: number[];
    theater: string[];
}
