import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { ReactiveFormsModule } from "@angular/forms";
import { MatCardModule, MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatSelectModule } from "@angular/material";
import { By } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AdminService } from "../../services/admin.service";
import { ChangeShowComponent } from "./change-show.component"

describe('Change Show Component',()=>{
    let component:ChangeShowComponent;
    let fixture:ComponentFixture<ChangeShowComponent>;
    let adminService:jasmine.SpyObj<AdminService>
beforeEach(async ()=>{
    const spyService= jasmine.createSpyObj('AdminService',['saveNowPlaying','searchMovie']);
    TestBed.configureTestingModule({
        declarations:[ChangeShowComponent],
        imports:[
            ReactiveFormsModule,
            MatFormFieldModule,
            MatDialogModule,
            MatInputModule,
            BrowserAnimationsModule,
            MatSelectModule,
            MatIconModule,
            MatCardModule
        ],
        providers:[{provide:AdminService,useValue:spyService}]
    }).compileComponents();

     adminService=TestBed.get(AdminService) as jasmine.SpyObj<AdminService>;
     fixture=TestBed.createComponent(ChangeShowComponent);
     component=fixture.componentInstance;
     fixture.detectChanges();
});
afterEach(()=>{
    fixture.destroy();
});

it('should create the component',()=>{
    expect(component).toBeTruthy();
})
it('should remove nowShowing movies on cancelling',()=>{
    component.cancel();
    expect(component.nowShowing.length).toBe(0);
})
it('should add a movie',()=>{
    let movie={name:'Chalk',id:1}
    component.addMovie(movie);
    expect(component.nowShowing.length).toBe(1);
    expect(component.nowPlaying.length).toBe(1);
})
it('should save movie',()=>{
    component.save();
    expect(component.successDialog).toBeTruthy();
    expect(adminService.saveNowPlaying).toHaveBeenCalled();
})
it('should call ngOnIt',()=>{
    spyOn(component.movieInput,'valueChanges');
    spyOn(component.selectTheater,'valueChanges');
    component.ngOnInit();
    const movieName=fixture.debugElement.query(By.css('.movie_name'));
    movieName.nativeElement.value='Lights Out';
    movieName.nativeElement.dispatchEvent(new Event('input'));
    const theater=fixture.debugElement.query(By.css('.theater_select'));
    theater.nativeElement.value='New Theater';
    theater.nativeElement.dispatchEvent(new Event ('selectTheater'));
    fixture.detectChanges();
    expect(adminService.searchMovie).toHaveBeenCalled();
    component.selectTheater.valueChanges.subscribe(value=>{
        expect(component.selectedTheater).toEqual(value);
    })

})
it('should reset all values after dialog close',()=>{
    component.dialogOk();
    expect(component.nowShowing.length).toBe(0);
    expect(component.movieResult.length).toBe(0);
})

})
