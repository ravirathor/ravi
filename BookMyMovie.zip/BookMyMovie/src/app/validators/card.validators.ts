import { AbstractControl } from "@angular/forms";
export function validateCard(control:AbstractControl){
    const VISA=/^4[0-9]{12}(?:[0-9]{3})?$/.test(control.value);
    const MASTER=/^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/.test(control.value);
    const AMEX=/3[47][0-9]{13}/.test(control.value);
    const MASTERO=/^(5018|5081|5044|5020|5038|603845|6304|6759|676[1-3]|6799|6220|504834|504817|504645)[0-9]{8,15}$/
    
    if(VISA || MASTER || AMEX || MASTERO )
        return null;
        else  return {invalidCard:true}
}