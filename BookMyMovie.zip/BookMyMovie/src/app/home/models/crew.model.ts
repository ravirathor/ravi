export interface Crew {
    name: string;
    profile_path: string;
    department: string;
    job: string;
    id: string;
    credit_id: string;
}
